#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#define N 3

double func_p(double x) {
	return(0);
}

double func_q(double x) {
	return(4);
}

double func_r(double x) {
	return(-4*x);
}

double **monta_matriz(double a, double f_a, double b, double f_b) {
	double **matriz, h = (b-a)/(N+1), x = a+h;

	//-----------------Aloca na memória a matriz------------------
	matriz = (double**)malloc(N*sizeof(double*));
	
	for(int i=0; i<N; i++)
		matriz[i] = (double*)malloc((N+1)*sizeof(double));
	//----------------------Fim da alocação-----------------------

	//-----------------Zerando elementos da matriz----------------
	for(int i=0; i<N; i++)
		for(int j=0; j<(N+1); j++)
			matriz[i][j] = 0;
	//-----------------Matriz está nula---------------------------
	
	//----------------Auxiliadores da montagem da matriz----------
	
	double aux_1(double x) {
		return(2+pow(h,2)*func_q(x));
	}
	
	double aux_2(double x) {
		return(-1+h/2.0*func_p(x));
	}
	
	double aux_3(double x) {
		return(-1-h/2.0*func_p(x));
	}
	//---------------fim dos auxiliadores--------------------------

	//------------Trabalhando a primeira linha da matriz-----------
	
	matriz[0][0] = aux_1(x);
	matriz[0][1] = aux_2(x);
	matriz[0][N] = -aux_3(x)*f_a-pow(h,2)*func_r(x);
	//---------------Fim primeira linha ---------------------------
	
	//------Trabalhando da segunda até a penúltima linha-----------
	for(int i=1; i<(N-1); i++) {
		x += h;
		
		matriz[i][i-1] = aux_3(x);
		matriz[i][i] = aux_1(x);
		matriz[i][i+1] = aux_2(x);;
		matriz[i][N] = -pow(h,2)*func_r(x);
	}
	//-----------Matriz completa até a penúltima linha-------------
	
	//------------Trabalhando a última linha da matriz-------------
	
	x += h;
	
	matriz[N-1][N-2] = aux_3(x);
	matriz[N-1][N-1] = aux_1(x);
	matriz[N-1][N] = -aux_2(x)*f_b-pow(h,2)*func_r(x);;
	//---------------Fim da última linha --------------------------

	return(matriz);
}	
	
	
//------------- Funções para resolução de sistemas lineares------------

void pivoteamento(double **M, int k, int dim) {
	int i;
	double maior = M[k][k], *aux_linha; // a variável maior guarda o elemento da diagonal principal que a principio utilizaríamos
	// para zerar os elementos da mesma coluna nas linhas inferiores, a linha auxiliar será utilizada na hora de trocar as linhas da
	// matriz, caso o maior seja superado por outro elemento abaixo de sua coluna
	
	for(i = k; i < dim; i++) {
		if(fabs(maior) < fabs(M[i][k])) {
			maior = M[i][k];
			
			aux_linha = M[i];
			M[i] = M[k];
			M[k] = aux_linha;
		}
	}
}
  			
void triangsup(double **M, int dim) {
        int i, j, k=0;
        double lambda;
        
        for(k = 0; k < (dim-1); k++) // k é a linha que nos estamos trabalhando
        	for(i = (k+1); i < dim; i++) { // i são as linhas abaixo de k onde iremos operar
        		pivoteamento(M,k, dim);
        		
        		(M[k][k] != 0)? (lambda = (-M[i][k]/M[k][k])) : (lambda = 0); // lambda é a constante que iremos
        		// multiplicar os elementos da linha k e somar com os respectivos elementos da linha i para o escalonamento
        	
        		for(j = 0; j <= dim; j++) // aqui faz a operação na linha i
        			M[i][j] += lambda*M[k][j];  
              	} 
}


void subsreversa(double **M,double *raizes, int dim) {
	int i, j;
	double somatorio=0;
	
	for(i = (dim-1); i >= 0; i--) {
		for(j = (i+1); j < dim; j++)
			somatorio += M[i][j]*raizes[j];
		raizes[i] = (M[i][dim] - somatorio)/M[i][i];

		somatorio = 0;
	}
}

		
// -------------- Fim da funções para sistemas lineares----------------------------

int main() {
	double **M, *raizes, a = 0, f_a = 0, b = 1, f_b = 2,  h = (b-a)/(N+1);
	FILE *arq;
	
	M = monta_matriz(a,f_a,b,f_b);
	
	//---------Resolve matriz ---------
	triangsup(M,N);
	
	raizes = (double*)malloc(N*sizeof(double));
	
	subsreversa(M,raizes,N);
	//--------sistema resolvido--------
	
	//---Grava em um arquivo a solucao
	arq = fopen("solucao.txt","w");
	
	for(int i=0; i<N; i++) {
		fprintf(arq,"%lf %lf\n", a, raizes[i]);
		a += h;
	}
	
	fclose(arq);
	//----solução salva----------------	
	
	return(0);
}
